title: Exception
date: '2019-11-18 17:05:07'
updated: '2019-11-18 17:05:07'
tags: [待分类]
permalink: /articles/2019/11/18/1574067906977.html
---
![image.png](https://img.hacpai.com/file/2019/11/image-d9fd9f7c.png)
![image.png](https://img.hacpai.com/file/2019/11/image-9212bda3.png)
![image.png](https://img.hacpai.com/file/2019/11/image-99da6080.png)
![image.png](https://img.hacpai.com/file/2019/11/image-9b92c833.png)
![image.png](https://img.hacpai.com/file/2019/11/image-4019cdb2.png)
![image.png](https://img.hacpai.com/file/2019/11/image-af779dbb.png)

Avoid to throw excception in Main method: use try catch
try to handle as many exceptions as you can , otherwise throw it

try catch finally throw throws
![image.png](https://img.hacpai.com/file/2019/11/image-4087144e.png)

EX
![image.png](https://img.hacpai.com/file/2019/11/image-8191899e.png)
![image.png](https://img.hacpai.com/file/2019/11/image-c481194e.png)
![image.png](https://img.hacpai.com/file/2019/11/image-d56ed3f0.png)
catch small exception then catch big one

![image.png](https://img.hacpai.com/file/2019/11/image-b4408d89.png)
![image.png](https://img.hacpai.com/file/2019/11/image-9fb339d8.png)
![image.png](https://img.hacpai.com/file/2019/11/image-3578fa7d.png)
child class must throw same exception or no exception
~~~~~~~~
