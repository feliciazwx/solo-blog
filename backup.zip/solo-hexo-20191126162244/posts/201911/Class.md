title: Class
date: '2019-11-19 13:07:12'
updated: '2019-11-19 18:33:23'
tags: [待分类]
permalink: /articles/2019/11/19/1574140032329.html
---
![image.png](https://img.hacpai.com/file/2019/11/image-4e451a50.png)

# **String**

![image.png](https://img.hacpai.com/file/2019/11/image-0dc862c1.png)

```
public class TestString{
    public static void main(String args[]){
        String s1 = "hello";
        String s2 = "world";
        String s3 = "hello";
        System.out.println(s1 == s3); //true
        /* 
        when system finds out that you already have a s1 which points to hello in the stack
        s3 will point to a same hello, not allocate a new one in the stack
        */

        s1 = new String("hello");
        s2 = new String("hhelo");
        System.out.println(s1 ==s2); // false, differenct address
        System.out.println(s1.equals(s2)); 
	//true iff the argument is not null and is a String obj that represents the same sequence of characters as this obj

        char c[] = {'s', 'u', 'n', ' ', 'j', 'a', 'v', 'a'};
        String s4 = new String(c);
        String s5 = new String(c,4,4);
        System.out.println(s4); //sun java
        System.out.println(s5); //java
    }
```
![image.png](https://img.hacpai.com/file/2019/11/image-849c50e4.png)



```
public class TestString2{
    public static void main(String args[]){
        String s1 = "sun java", s2 = "Sun Java";
        System.out.println(s1.charAt(1)); //u
        System.out.println(s2.length()); //8
        System.out.println(s1.indexOf("java")); //4, the first place shows "java"
        System.out.println(s1.indexOf("Java")); //-1, s1 does not contains "Java"
        System.out.println(s1.equals(s2)); //false
        System.out.println(s1.equalsIgnoreCase(s2)); //true

        String s = "i am a programmer, i am learning java";
        String sr = s.replace('i' ,'you');
        System.out.println(sr); // you am a programmer, you am learning java
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-a32db935.png)

```
public class TestString3{
    public static void main(String args[]){
        String s = "Welcome to Java  World!";
        String s1 = "  sun java";

        System.out println(s.startsWith("Welcome")); //true
        System.out.println(s.endsWith("World")); //false

        String sL = s.toLowerCase();
        String sU = s.toUpperCase();
        System.out.println(sL); //welcome to java world!
        System.out.println(sU); //WELCOME TO JAVA WORLD!
        String subS = s.substring(11);
        System.out.println(subS); // Java World, start from index 10 to the end
        String sp = s1.trim();
        System.out.println(sp); //sun java, remove space front and end
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-ecd854f1.png)
valueOf(Object obj): returns the string representation of the object argument

```
Date d = new Date(2006,7,6);
String str = String.valueOf(d);
// equals to str = d.toString();
```

```
public classTest2{
    public static void main(String args[]){

        //count hany lower case, upper case, other characters in a string

        String s = "AaaaABBBBcc&^%adfsfdCCOOkk99876_haHA";
        int lCount = 0, uCount = 0, oCount = 0;
        //Method 1
        for(i=0; i<s.length(); i++){
            char c = s.charAt(i);
            if(c >= 'a' && c <='z'){ //lower case
                lCount ++;
            }else if(c >= 'A' && c <= 'Z'){
                uCount ++;
            }else{
                oCount ++;
            }
        }

        //Method2
        String sL = "abcdefghijklmnopqrstuvwxyz";
        Stirng sU = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"；
        for(i=0; i<s.length(); i++){
            char c = s.charAt(i);
            if(sL.indexOf(c) != -1){ //lower case
                lCount ++;
            }else if(sU.indexOf(c) != -1){
                uCount ++;
            }else{
                oCount ++;
            }
        }

        //Method3 
        for(i=0; i<s.length(); i++){
            char c = s.charAt(i);
            if(Character.isLowerCase(c)){ //lower case
                lCount ++;
            }else if(Character.isUpperCase(c)){
                uCount ++;
            }else{
                oCount ++;
            }
        }

        System.out.println(lCount + " " + uCount + " " + oCount);

        //count the times of occurance of a string in a given string
        String s = "sunjavahpjavandfjavanjjavanjljava";
        String sToFind = "java";
        int count = 0;
        /*if(index != -1){
            count ++;
        }
        s = s.substring(index + sToFind.length());*/
        int index = -1;
        while(index = s.indexOf(sToFind) != -1){
            s = s.substring(index + sToFind.length());
            count ++;
        }

        System.out.println(count);

    }

}
```

# **StringBuffer**
![image.png](https://img.hacpai.com/file/2019/11/image-61545e11.png)
![image.png](https://img.hacpai.com/file/2019/11/image-5b677ab2.png)
![image.png](https://img.hacpai.com/file/2019/11/image-5ef3eb00.png)
![image.png](https://img.hacpai.com/file/2019/11/image-81396db2.png)
```
public class TestStringBuffer{
    public static void main(String args[]){
        String s = "Microsoft";
        char[] a = {'a', 'b', 'c'};
        StringBuffer sb1 = new StringBuffer(s);
        sb1.append('/').append("IBM").append('/').append("Sun");
        System.out.println(sb1);
        StringBuffer sb2 = new StringBuffer("数字");
        for(int i=0; i<=9; i++){
            sb2.sppend(i);
        }
        System.out.println(sb2);
        sb2.delete(8,sb2.length()).insert(0,a); // delete from index of 8(6789) => 数字0123456 => insert a from index 0 => abc数字012345
        System.out.println(sb2);
        System.out.println(sb2.reverse());
    }
}

/* output
Microfost/IBM/Sun
数字0123456789
abc数字012345
543210字数cba
*/
```

# **primitive data type wrapped class**
![image.png](https://img.hacpai.com/file/2019/11/image-8898b94e.png)
![image.png](https://img.hacpai.com/file/2019/11/image-5fdeeabc.png)
```
public class Test3{
    public static void main(String args[]){
        Integer i = new Integer(100);
        Double d = new Double("123.456");
        int j = i.intValue() + d.intValue();
        float f = i.floatValue() + d.floatValue();
        System.out.println(j);
        System.out.println(f);
        double pi = Double.parseDouble("3.1415926")；
        double r = Double.valueOf("2.0").doubleValue();
        double s = pi*r*r;
        System.out.println(s);
        try{
            int k = Integer.parseInt("1.25");
        }catch(NumberFormatException e){
            System.out.println("wrong data type");
        }
        System.out.println(Integer.toBinaryString(123) + "B");
        System.out.println(Integer.toHexString(123) + "H");
        System.out.println(Integer.toOctalString(123) + "O");
    }
}
```

![image.png](https://img.hacpai.com/file/2019/11/image-c7e7ea40.png)
```
public class ArrayParser{
    public static void main(String args[]){
        double d[][];
        String s = "1,2;3,4,5;6,7,8";
        String[] sFirst = s.split(";");
        d = new double[sFirst.length][];
        for(int i=0; i<sFirst.length; i++){
            String[] sSecond = sFirst[i].split(",");
            d[i] = new double[sSecond.length];
            for(int j=0; j<sSecond.length; j++){

                d[i][j] = Double.parseDouble(sSecond[j]);

            }
        }
        
        for(int i=0; i<d.length; i++){
            for(int j=0; j<d[i].length; j++){
                System.out.print(d[i][j] + " ");
            }
            System.out.println();
        }
    }
}
```

# **Math**
![image.png](https://img.hacpai.com/file/2019/11/image-26e701ea.png)
![image.png](https://img.hacpai.com/file/2019/11/image-99186bd2.png)

# **File**
![image.png](https://img.hacpai.com/file/2019/11/image-8c722691.png)
![image.png](https://img.hacpai.com/file/2019/11/image-f2103eb3.png)
boolean mkdir() :  创建此抽象路径名指定的目录。    
boolean mkdirs() :  创建此抽象路径名指定的目录，包括创建必需但不存在的父目录。
```
import java.io.*;
public class TestFile{
    public static void main(String args[]){
        String separator = File.separator;
        String filename = "myfile.txt";
        String directory = "mydir1" +separator + "mydir2";
        File f = new File(directory, filename);
        if(f.exists()){
            System.out.println("filename:" + f.getAbsolutePath());
            System.out.println("file size: " + f.length());
        }else{
            f.getParentFile().mkdirs();
            try{
                f.createNewFile();
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }
}
```

```
//print filename using recursion
import java.io.*;
public class FileList{
    public static void main(String args[]){
        File f = new File("f:/A");
        System.out.println(f.getName());
        tree(f,0);
    }

    private static void tree(File f, int level){

        String preStr = "";
        for(int i=0; i<level; i++){
            preStr += "  ";
        }
        File[] childs = f.listFiles(); //returns an array of abstract pathnames denoting the files in the directory denoted by this abstract pathname
        for(int i=0; i<childs.length; i++){
            System.out.println(preStr + childs[i].getName());
            if(childs[i].isDirectory()){
                tree(childs[i], level+1);
            }
        }

    }

}
```

# **Enumerative**
![image.png](https://img.hacpai.com/file/2019/11/image-121850ec.png)
```
public class TestEnum{
    public enum MyColor{red, green, blue};
    public enum MyDoorOpener(me, mywife);

    public static void main(String[] args){
        MyColor m = MyColor.red;
        switch(m){
            case red:
                System.out.println("red");
                break;
            case green:
                System.out.println("green");
                break;
            default:
                System.out.println("default");
        }

        System.out.println(m);
    } 
}
```

# **Summary**
![image.png](https://img.hacpai.com/file/2019/11/image-7d9e3619.png)





