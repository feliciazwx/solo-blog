title: Array
date: '2019-11-19 10:43:28'
updated: '2019-11-19 10:43:28'
tags: [待分类]
permalink: /articles/2019/11/19/1574131408915.html
---
![image.png](https://img.hacpai.com/file/2019/11/image-86442e5b.png)
![image.png](https://img.hacpai.com/file/2019/11/image-ca53bd5e.png)
cannot declare array size on the left side of the equal sign
	eg: int a[3][2]  this is not allowed

![image.png](https://img.hacpai.com/file/2019/11/image-59610fc2.png)


```
public class TestArrayCopy{
    public static void main(String args[]){
        String[] s = ("Microsoft", "IBM", "Sun", "Oracle", "Apple");
        String[] sBak = new String[6];
        System.arraycopy(s,0,Sbak,s.length);

        for(int i=0; i<sBak.length; i++){
            System.out.print(sBak[i] + " ");
        }

        System.out.println();
        int[][] intArray = {{1,2}, {1,2,3}, {3,4}};
        int[][] intArrayBak = new int[3][];
        System.arraycopy(intArray,0,intArrayBak,0,intArray.length);
        intArrayBak[2][1] = 100;

        for(int i=0; i<intArray.length; i++){
            for(int k=0; j<intArray[i].length; j++){
                System.out.print(intArray[i][j]+" ");
            }
            System.out.println();
        }
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-adcac3b6.png)





