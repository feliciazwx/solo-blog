title: Thread
date: '2019-11-25 11:42:38'
updated: '2019-11-25 19:34:56'
tags: [待分类]
permalink: /articles/2019/11/25/1574653358610.html
---
# **Introduction**
![image.png](https://img.hacpai.com/file/2019/11/image-12e2d0e3.png)
```
public class T{
    public static void main(String args[]){
        m1();
    }

    public static void m1(){
        m2();
        m3();
    }

    public static void m2(){}
    public static void m3(){}
}
```
1. 进程（programming）：静态概念
2. 线程： 一个进程里有一个主线程（main），是一个进程里不同的执行的路径
3. 一个CPU只支持一个线程

![image.png](https://img.hacpai.com/file/2019/11/image-bd322146.png)
![image.png](https://img.hacpai.com/file/2019/11/image-15f75b07.png)
- start()： 启动new Thread

1. Method 1
![image.png](https://img.hacpai.com/file/2019/11/image-33526b1c.png)

```
//polymorphism exists: inheritance, override, parent reference points to the child instance
public class TestThread1{
    public static void main(String args[]){
        Runner1 r= new Runner1();
        //r.run();
        Thread t = new Thread(r);
        t.start();

        for(int i=0; i<100; i++){
            System.out.println("Main Thread: ---" + i);
        }
    }
}

class Runner1 implements Runnable{
    public void run(){
        for(int i=0; i<100; i++){
            System.out.println("Runner1: " + i);
        }
    }
    
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-56459d04.png)
![image.png](https://img.hacpai.com/file/2019/11/image-b59a40b3.png)

2. Method 2
```
//polymorphism exists: inheritance, override, parent reference points to the child instance
public class TestThread1a{
    public static void main(String args[]){
        Runner1 r= new Runner1();
        r.start();
        try{
            for(int i=0; i<100; i++){
                System.out.println("Main Thread: ---" + i);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

class Runner1 extends Thread{
    public void run(){
        for(int i=0; i<100; i++){
            System.out.println("Runner1: " + i);
        }
    }
    
}
```
- better to implement Thread interface rather than inherit from it


![image.png](https://img.hacpai.com/file/2019/11/image-060328ae.png)
![image.png](https://img.hacpai.com/file/2019/11/image-ace01597.png)
- execute run() first => run() finished => main()

# **线程状态转换**
![image.png](https://img.hacpai.com/file/2019/11/image-5ce11061.png)
>- 调用start() => execute
>- something happens => get stucked

![image.png](https://img.hacpai.com/file/2019/11/image-fadeb175.png)

# **sleep**
![image.png](https://img.hacpai.com/file/2019/11/image-5ad276f2.png)
```

public class TestInterrupt{
    public static void main(String args[]){
        MyThread thread = new MyThread();
        thread.start();
        try{
            Thread.sleep(3000);
        }catch(InterruptedException e){

        }
        thread.interrupt(); //stop subthread (not the best way to do)
        // not to use stop()
    }
}

class MyThread extends Thread{
    boolean flag = true;
    //once run() stops => thread stops
    public void run(){
        while(flag){
            System.out.println("===" + new Date() + "===");
            try{
                sleep(1000); //print current time for every 1 min
            } catch(InterruptedException e){
                return;
            }
        }
    }
}

// public void run(){
//     while(true){
//         String temp = new Date().toString();
//         String t = temp.substring(11, temp.indexOf('C'));
//         t = t.trim();
//         String[] time = t.split(":");
//         if(time.length ==3){
//                System.out.println("now:" + time[0] + ":" + time[1] ":" + time[2]);
//         }
//         try{
//             Thread.sleep(5000);
//         } catch(InterruptedException e){
//             return;
//         }
//     }
// }


```
![image.png](https://img.hacpai.com/file/2019/11/image-372ca564.png)

# **Join**
```
public class TestJoin{
    public static void main(String args[]){
        MyThread2 t1 = new MyThread2("t1"); //"ti" can be any name
        t1.start();
        try{
            t1.join();
        } catch(InterruptedException e){
        }

        for(int i=1; i<=10; i++){
            System.out.println("i am main thread");
        }
    }

}

class MyThread2 extends Thread{
    MyThread2(String s){
        super(s);
    }

    public void run(){
        for(int i=1; i<=10; i++){
            System.out.println("i am " + getName());
            try{
                sleep(1000);
            }
                    catch(InterruptedException e){
            return;
        }
        }
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-425242f8.png)
![image.png](https://img.hacpai.com/file/2019/11/image-b0061b51.png)
- execute child process first => main thread

# **yield**
```
public class TestYield{
    public static void main(String args[]){
        MyThread3 t1 = new MyThread3("t1");
        MyThread3 t2 = new MyThread3("t2");
        t1.start();
        t2.start();    
    }
}

class MyThread3 extends Thread{
    MyThread3(String s){
        super(s);
    }
    public void run(){
        for(int i=1; i<=100; i++){
            System.out.println(getName() + ": " + i);
            if(i%10==0){
                yield(); //when t1 or t2 ==10, switch to another thread
            }
        }
    }
}
```

# **Thread Priority**
![image.png](https://img.hacpai.com/file/2019/11/image-5cb19683.png)
```

class T1 implements Runnable{
    public void run(){
        for(int i=0; i<100; i++){
            System.out.println("T1： " + i);
        }
    }
}
```
# **Example**
```
// same procress can have two threads
public class TestThread2{
    public static void main(String args[]){
        Runner2 r = new Runner2();
        Thread t1 = new Thread(r);
        Thread t2 = new Thread(r);
        t1.start();
        t2.start(); 
    }
}

class Runner2 implements Runnable{
    public void run(){
        for(int i=0; i<30; i++){
            System.out.println("No. " + i);
        }
    }
}
```
```
public class TestThread3{
    public static void main(String args[]){
        Runner3 r = new Runner3();
        Thread t = new Thread(r);
        t.start();
    }
}

class Runner3 implements Runnable{
    public void run(){
        for(int i=0; i<30; i++){
            if(i%10==0 && i!=){
                try{
                    Thread.sleep(2000);
                } catch(InterruptedException e){}
            }
            System.out.println("No. " + i);
        }
    }
}
```
```
//stop thread 
//once run() is over, then thread stops
public class TestThread4{
    public static void main(String args[]){
        Runner4 r = new Runner4();
        Thread t = new Thread(r);
        t.start();
        for(int i=0; i<100000; i++){
            if(i%10000 == 0 & i>0){
                System.out.println("in thread main i= " +i);
            }
        }
        System.out.println("Thread main is over");
        r.shutDown();
    }
}

class Runner4 implements Runnable{
    private boolean flag = true;
    public void run(){
        int i=0;
        while(flag){
            System.out.println(" " + i++);
        }
         
    }
    public void shutDown(){
        flag = false;
    }
}
```
> ! Use shutDown() to stop a thread

```
public class TestThread5{
    public static void main(String args[]){
        Runner5 r = new Runner5();
        Thread t = new Thread(r);
        t.start();
        try{
            t.join();
        } catch(InterruptedException e){}
        for(int i=0; i<50; i++){
            System.out.println("main thread: " +i);
        }
    }
}

class Runner5 implements Runnable{
    public void run(){
        for(in ti=0; i<50; i++){
            System.out.println("SubThread: " +i);
        }
    }
}
```
```
public class TestThread6{
    public static void main(String args[]){
        Runner6 r = new Runner6();
        t.start();
        for(int i=0; i<50; i++){
            System.out.println("main thread: " +i);
        }
    }
}

class Runner6 implements Runnable{
    public void run(){
        System.out.println(Thread.currentThread().isAlive()); //true
        for(in ti=0; i<50; i++){
            System.out.println("SubThread: " +i);
        }
         
    }
    
}
```
# **Thread Synchronized**
![image.png](https://img.hacpai.com/file/2019/11/image-b6836e2d.png)


```
public class TestSync implements Runnable {
    private Timer timer = new Timer();

    public static void main(String args[]) {
        TestSync test = new TestSync();
        Thread t1 = new Thread(test);
        Thread t2 = new Thread(test);
        t1.setName("t1");
        t2.setName("t2");
        t1.start();
        t2.start();
    }

    public void run() {
        timer.add(Thread.currentThread().getName());
    }
}

class Timer {
    private static int num = 0;
    // public void add(String name){
    // //lock current object=>others cannot interrupt
    // synchronized(this){
    // num++;
    // try{
    // Thread.sleep(1);
    // }catch(InterruptedException e){
    // }
    // System.out.println(name+ ", you are No." + num + "to use timer thread");
    // }
    // }

    public synchronized void add(String name) {
        num++;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
        }
        System.out.println(name + ", you are No." + num + "to use timer thread");
    }

}
```
![image.png](https://img.hacpai.com/file/2019/11/image-215ab5d8.png)

> not use synchronized
![image.png](https://img.hacpai.com/file/2019/11/image-dc9dcfc1.png)

>use synchronized
![image.png](https://img.hacpai.com/file/2019/11/image-6f6e941f.png)



>实现implements Runnable接口比继承 extends Thread类所具有的优势：  
  1）：适合多个相同的程序代码的线程去处理同一个资源  
  2）：可以避免java中的单继承的限制(不能访问父类的私有成员？)  
  3）：增加程序的健壮性，代码可以被多个线程共享，代码和数据独立  
  4）：线程池只能放入实现Runable或callable类线程，不能直接放入继承Thread的类

```
public class TestDeadLock implements Runnable{
    public int flag = 1;
    static Object o1 = new Object(), o2 = new Object();
    public void run(){
        System.out.println("flag= " + flag);
        if(flag == 1){
            synchronized(o1){
                try{
                    Thread.sleep(500);
                } catch(Exception e){
                    e.printStackTrace();
                }
            }
            synchronized(o2){
                System.out.println("1");
            }
        }
        if(flag == 2){
            synchronized(o2){
                try{
                    Thread.sleep(500);
                } catch(Exception e){
                    e.printStackTrace();
                }
            }
            synchronized(o1){
                System.out.println("0");
            }
        }
    }

    public static void main(String args[]){
        TestDeadLock td1 = new TestDeadLock();
        TestDeadLock td2 = new TestDeadLock();
        td1.flag = 1;
        td2.flag = 0;
        Thread t1 = new Thread(td1);
        Thread t2 = new Thread(td2);
        t1.start();
        t2.start();
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-dc0e794e.png)
>dead lock =>prints firstthen system frozed

![image.png](https://img.hacpai.com/file/2019/11/image-23691579.png)
```
public class TT implements Runnable{
    int b = 100;

    //only this thread is executed (m2() is not executed)
    public synchronized void m1() throws Exception{
        b = 1000;
        Thread.sleep(5000);
        System.out.println("b = " + b);
    }

    public void m2(){
        System.out.println(b);
    }

    public void run(){
        try{
            m1();
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception{
        TT tt = new TT();
        Thread t = new Thread(tt);
        t.start();

        Thread.sleep(1000);
        tt.m2(); 
    }
}
```

*********************************************************
> m1(), m2()都可以change b value => add synchronized to both methods (同步）
> 锁定对象=>另外的线程不能访问其中的语句
> change value method => add synchronized
> only read value method => not necessary
```
public class TT implements Runnable{
    int b = 100;

    //only this thread is executed (m2() is not executed)
    public synchronized void m1() throws Exception{
        b = 1000;
        Thread.sleep(5000);
        System.out.println("b = " + b); //print the second b=1000
    }

    public synchronized void m2() throws Exception{
        Thread.sleep(2500);
        b = 2000;
    }

    public void run(){
        try{
            m1();
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception{
        TT tt = new TT();
        Thread t = new Thread(tt);
        t.start();

        Thread.sleep(1000);
        tt.m2(); 

        System.out.println(tt.b); //print the first 1000
    }
}

```
>![image.png](https://img.hacpai.com/file/2019/11/image-ca622b76.png)
**m2() is synchronized**
 main executes  => half way execute t.start() which executes run() (m1)
m2() executed => sleep2.5s b=2000 (only m2() is allowed to execute)
m2() finished then m1() executed => change b to 1000
print tt.b = 1000

>![image.png](https://img.hacpai.com/file/2019/11/image-a89362ac.png)
**m2() is not synchronized**
main() => run()=> m1() b=1000 =>m2() b=2000

**************************************
> no notify() => cause dead lock
>thread is waiting until see notify()

![image.png](https://img.hacpai.com/file/2019/11/image-d562254f.png)
```
public class ProducerConsumer{
    public static void main(String args[]){
        SyncStack ss = new SyncStack();
        Producer p = new Producer(ss);
        Consumer c = new Consumer(ss);
        new Thread(p).start();
        //new Thread(p).start();
        //can have multiple producer and consumer
        new Thread(c).start();
    }
}

class Bun{
    int id;
    Bun(int id){
        this.id = id;
    }

    public String toString(){
        return "Bun: " +id;
    }
}

class SyncStack{
    int index = 0;
    Bun[] arrBun = new Bun[6];

    //avoid multiple people throw bun into the stack at the same time
    public synchronized void push(Bun b){
        //catched exception but if it is still full => use while instead of if
        // even if it catches exception, still need to check if the basket is full
        while(index == arrBun.length){
            try{
                this.wait(); //Object class
            } catch(InterruptedException e){
                e.printStackTrace();
            }
            
        }
        this.notify(); // awake a waiting thread, belongs to Object class
        //this.notifyAll();
        arrBun[index] = b;
        index ++;
    }

    public synchronized Bun pop(){
        while(index == 0){
            try{
                this.wait(); //Object class
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        this.notify();
        index --;
        return arrBun[index];
    }
}

class Producer implements Runnable{
    SyncStack ss = null;
    Producer(SyncStack ss){
        this.ss = ss;
    }

    public void run(){
        for(int i=0; i<20; i++){
            Bun b = new Bun(i);
            ss.push(b);
            System.out.println("Produced:"  + b);
            try{
                Thread.sleep((int)(Math.random()*1000));
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}

class Consumer implements Runnable{
    SyncStack ss = null;
    Consumer(SyncStack ss){
        this.ss = ss;
    }

    public void run(){
        for(int i=0; i<20; i++){
            Bun b = ss.pop();
            System.out.println("Consumed:"  + b);
            try{
                Thread.sleep((int)(Math.random()*1000));
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-242b6157.png)
wait: Object class =>unlocked
sleep: Thread class => locked

# **Summary**
![image.png](https://img.hacpai.com/file/2019/11/image-41d8c5de.png)

