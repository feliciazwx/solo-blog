title: Container
date: '2019-11-20 17:53:18'
updated: '2019-11-21 15:12:33'
tags: [待分类]
permalink: /articles/2019/11/20/1574243598243.html
---
# **Introduction**
![image.png](https://img.hacpai.com/file/2019/11/image-6663dd76.png)
![image.png](https://img.hacpai.com/file/2019/11/image-64a6d0d8.png)
 - Using Array is not convenient (resize, add)

# Collection API
![image.png](https://img.hacpai.com/file/2019/11/image-2e2eecbf.png)
![image.png](https://img.hacpai.com/file/2019/11/image-25113b33.png)

# Collection Interface
![image.png](https://img.hacpai.com/file/2019/11/image-6cad513a.png)

# Collection Method Example
![image.png](https://img.hacpai.com/file/2019/11/image-e91debeb.png)
```
import java.util.*;

public class TestArrayList{
    public static void main(String args[]){
        Collection c = new ArrayList(); 
        /* 
            cannot use specific method in ArrayList
            can change to LinkedList in the future
            provide flexibility
        */
        c.add("hello");
        c.add(new Double(1.0));
        c.add(new Integer(100)); // int is declared in the stack
        //c can only contain objects

        System.out.println(c.size());
        System.out.println(c); // implements c.toString()
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-f71c8b26.png)
```
import java.util.*;

public class BasicContainer{
    public static void main(String[] args){
        Collection c = new HashSet();
        c.add("hello");
        Name name = new Name("f1","l1");
        c.add(name);
        c.add(new Integer(100));
        c.remove("hello"); // hello is removed
        c.remove(new Integer(100)); // Integer 100 is removed, override equals() => same object then remove

        System.out.println(c.remove(name)); // Name class does not override equals() => not removed
        System.out.println(c);
    }
}

class Name extends Object{ /* implements Comparable */
    private String fn, ln;
    public Name(String fn, String ln){
        this.fn = fn;
        this.ln = ln;
    }
    public String getFN(){
        return this.fn;
    }
    public String getLN(){
        return this.ln;
    }
    public String toString(){
        return fn + " " + ln;
    }
    
    @Override
    public boolean equals(Object obj){
        if(obj instanceof Name){
            Name name = (Name) obj;
            return (fn.equals(name.fn)) && (ln.equals(name.ln)) ;
        }
        return super.equals(obj);
    }

    /* 
    override equals must also override hashCode
    when to use: this obj is used to 索引(一对对来存)
    */
    public int hashCode(){
        return fn.hashCode(); // string override hashcode() => return the address in the memory
    }

    public int compareTo(Object o){
        Name n = (Name) o;
        int lastCmp = ln.compareTo(n.ln);
        return (lastCmp !=0 ? lastCmp : fn.compareTo(n.fn));
    }
}
```

# **Iterator**
![image.png](https://img.hacpai.com/file/2019/11/image-f0582cca.png)
Iterator ~ Pointer

**Polymorphism**：
- inheritance
- 父类引用指向子类对象
- override

```
import java.java.util.*;
public class TestIterator{
    public static void main(String args[]){
        Collection c = new HashSet();
        c.add(new Name("f1","l1"));
        c.add(new Name("f2","l2"));
        c.add(new Name("f3","l3"));

        /*
        Iterator i = c.iterator();
        while(i.hasNext()){
            Name n = (Name) i.next();
            System.out.print(n.getFirstName() + " ");
        }
        */

        /*
        for(Iterator i = c.iterator(); i.hasNext();){
            Name name = (Name)i.next();
            if(name.getFirstName().length()<3){
                i.remove();
                //c.remove(name) will create exception
            }
        }
        */

    }
}
```
# **Enhanced For loop**
![image.png](https://img.hacpai.com/file/2019/11/image-6f226ef5.png)
```
import java.util.*;
public class EnhancedFor{
    public static void main(String[] args){
        int[] arr = {1,2,3,4,5};
        for(int i: arr){
            System.out.println(i);
        }

        Collection c = new ArrayList();
        c.add(new String("aaa"));
        c.add(new String("bbb"));
        c.add(new String("ccc"));
        for(Object o : c){
            System.out.println(o);
        }
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-84f76cda.png)

# **Set**
![image.png](https://img.hacpai.com/file/2019/11/image-095d1625.png)
![image.png](https://img.hacpai.com/file/2019/11/image-cefc5b88.png)

![image.png](https://img.hacpai.com/file/2019/11/image-2b6d9842.png)

```
import java.util.*;
public class TestSet{
    public static void main(String args[]){
        Set s1 = new HashSet();
        Set s2 = new HashSet();
        s1.add("a"); s1.add("b"); s1.add("c");
        s2.add("d"); s2.add("a"); s2.add("b");

        Set sn = new HashSet(s1);
        sn.retainAll(s2); //intersection of s1,s2
        Set su = new HashSet(s1);
        su.addAll(s2); // a,b is duplicated, only add d, unordered
        System.out.println(sn);
        System.out.println(su);
    }
}
```

# **List**
![image.png](https://img.hacpai.com/file/2019/11/image-63dc926b.png)
Object set => return object is the old obj
indexOf implements equals()
![image.png](https://img.hacpai.com/file/2019/11/image-fe92e531.png)
![image.png](https://img.hacpai.com/file/2019/11/image-fae457aa.png)
![image.png](https://img.hacpai.com/file/2019/11/image-c324d824.png)
list is ordered
reverse arraylist (copy) is less proficient than linkedlist (reverse link) 

# **Comparable interface**
![image.png](https://img.hacpai.com/file/2019/11/image-54a6c0b3.png)
![image.png](https://img.hacpai.com/file/2019/11/image-5a58f2f0.png)

# **How to choose data structure**
![image.png](https://img.hacpai.com/file/2019/11/image-2ab83b57.png)

# **Map interface**
![image.png](https://img.hacpai.com/file/2019/11/image-9847c342.png)
- key is unique (compare hashCode() => compare equals() is not proficient)
![image.png](https://img.hacpai.com/file/2019/11/image-53cf58d1.png)
```
public class TestArgs{
    public static void main(String args[]){
        if(args.length < 3){
            System.out.println("Usage: java Test \"n1\" \"op\" \"n2\" ");
            System.exit(-1);
        }
        double d1 = Double.parseDouble(args[0]);
        double d1 = Double.parseDouble(args[0]);
        double d = 0;
        if(args[1].equals("+")) d = d+1;
        else if(args[1].equals("-")) d = d1-d2;
        else if(args[1].equals("x")) d = d1*d2;
        else if(args[1].equals("/")) d = d1/d2;
        else{
            System.out.println("Error operator!");
            System.exit(-1);
        }

        System.out.println(d);
    }
}
```
```
import java.util.*;

public class TestMap{
    public static void main(String args[]){
        Map m1 = new HashMap<>();
        Map m2 = new TreeMap<>();
        m1.put("one", new Integer(1)); // map can only contains object for key and value
        /* m1/put("two", 1); */
        m1.put("two", new Integer(2));
        m1.put("three", new Integer(3));
        m2.put("A", new Integer(1));
        m2.put("B", new Integer(2));
        System.out.println(m1.size());
        System.out.println(m1.containsKey("one"));
        System.out.println(m2.containsValue(new Integer(1)));
        if(m1.containsKey("two")){
            int i = ((Integer)m1.get("two")).intValue();
            System.out.println(i);
        }
        Map m3 = new HashMap(m1);
        m3.putAll(m2);
        System.out.println(m3);
    }
}
    
```

![image.png](https://img.hacpai.com/file/2019/11/image-dfdb85e1.png)
![image.png](https://img.hacpai.com/file/2019/11/image-2a955b0a.png)
1 is autoboxed to Integer 1

```
import java.util.*;
public class TestArgsWords{
    private static final Integer ONE = new Integer(1);
    public static void main(String args[]){
        Map m = new HashMap();
        for(int i=0; i<args.length; i++){
            Integer freq = (Integer) m.get(args[i]);
            m.put(args[i], (freq == null ? ONE: new Integer(freq.intValue() + 1)));
        }

        System.out.println(m.size() + " distinct words detected:");
        System.out.println(m);
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-f68cdddc.png)
aaa:
	m.get(aaa) = null
	freq = null
	m.put(aaa,1)

bbb:
	m.get(bbb) = null
	freq = null
	m.put(bbb,1)

aaa:
	m.get(aaa) = 1
	freq = 1
	m.put(aaa,2)

```
import java.util.*;
public class TestArgsWords{
    //private static final Integer ONE = new Integer(1);
    public static void main(String args[]){
        Map m = new HashMap();
        for(int i=0; i<args.length; i++){
            // Integer freq = (Integer) m.get(args[i]);
            int freq = (Integer) m.get(args[i] == null ? 0 :(Integer) m.get(args[i]));

            // m.put(args[i], (freq == null ? ONE: new Integer(freq.intValue() + 1)));
            m.put(args[i], freq==0? 1 : freq +1);
        }

        System.out.println(m.size() + " distinct words detected:");
        System.out.println(m);
    }
}
```

# **JDK1.5 Generic**
![image.png](https://img.hacpai.com/file/2019/11/image-aad20863.png)
```
import java.util.*;

public class BasicGeneric{
    public static void main(String args[]){
        List<String> c = new ArrayList<String>();
        c.add("aaa");
        c.add("bbb");
        c.add("ccc");
        for(int i=0; i<c.size(); i++){
            String s = c.get(i);
            System.out.println(s);
        }

        Collection<String> c2 = new HashSet<String>();
        c2.add("aaa");
        c2.add("bbb");
        c2.add("ccc");
        for(Iterator<String> it = c2.iterator(); it.hasNext();){
            String s = it.next();
            System.out.println(s);
        }
    }
}

class MyName implements Comparable<MyName>{
    int age;
     public int compareTo(MyName mn){
         if(this.age > mn.age){
             return 1;
         }
         else if(this.age < mn.age){
             return -1;
         }
         else{
             return 0;
         }
     }
}
```

when to decide your own class: ArrayList<> (has <>)

	
```
import java.util.*;

public class TestMap{
    public static void main(String args[]){
        Map<String,Integer> m1 = new HashMao<String, Integer>();
        m1.put("one", 1); 
        m1.put("two", 2;
        m1.put("three", 3);

        System.out.println(m1.size());
        System.out.println(m1.containsKey("one"));
        if(m1.containsKey("two")){
            int i = m1.get("two");
            System.out.println(i);
        }

    }
}

```
```
import java.util.*;
public class TestArgsWords{
    private static final Integer ONE = new Integer(1);
    public static void main(String args[]){
        Map<String, Integer> m = new HashMap<String, Integer>();
        for(int i=0; i<args.length; i++){
            if(!m.containsKey(args[1])){
                m.put(args[i],ONE);
            }
            else{
                int freq = m.get(args[i]);
                m.put(args[i], freq + 1);
            }
        }

        System.out.println(m.size() + " distinct words detected:");
        System.out.println(m);
    }
}
```

# **Summary**
![image.png](https://img.hacpai.com/file/2019/11/image-de89151d.png)
pic: collection -> list, set...






