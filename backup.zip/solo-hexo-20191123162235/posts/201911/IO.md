title: IO
date: '2019-11-21 18:13:58'
updated: '2019-11-22 18:14:10'
tags: [待分类]
permalink: /articles/2019/11/21/1574331238461.html
---
# **Introduction**
![image.png](https://img.hacpai.com/file/2019/11/image-0638c65d.png)
![image.png](https://img.hacpai.com/file/2019/11/image-af63b251.png)

# **Stream Category**
![image.png](https://img.hacpai.com/file/2019/11/image-6a0a6bba.png)
字节流：1 byte a time   (xxStream)
字符流：unicode（2 byte a time）
![image.png](https://img.hacpai.com/file/2019/11/image-9d510dcd.png)

# **InputStream**
![image.png](https://img.hacpai.com/file/2019/11/image-853aef08.png)
![image.png](https://img.hacpai.com/file/2019/11/image-8b101875.png)
int read(byte[] buffer) throws IOException:
>minimize the times of reading from hard drive

# **OutputStream**
![image.png](https://img.hacpai.com/file/2019/11/image-b6cf9752.png)
![image.png](https://img.hacpai.com/file/2019/11/image-4730f2c6.png)
first flush() then close()

# **Reader**
![image.png](https://img.hacpai.com/file/2019/11/image-0aac59a6.png)
Chinese is 2 byte for one character

# **Writer**
![image.png](https://img.hacpai.com/file/2019/11/image-b8008278.png)
![image.png](https://img.hacpai.com/file/2019/11/image-bf51e852.png)

# **节点流**
![image.png](https://img.hacpai.com/file/2019/11/image-8aae64e7.png)

```
import java.io.*;
public class TestFileInputStream{
    public static void main(String[] args){
        int b = 0;
        FileInputStream in = null;
        try{
            in = new FileInputStream("F:\\java_learning\\20191121\\IO\\TestFileInputStream.java");
        } catch (FileNotFoundException e){
            System.out.println("file is not found");
            System.exit(-1);
        }

        try{
            long num = 0;
            while((b = in.read()) != -1){ //-1: reading is to end of the file
                System.out.print((char) b);
                num ++ ;
            }
            in.close();
            System.out.println();
            System.out.println("total read" + num + "byte");
        }catch(IOException e1){
            System.out.println("read file error");
            System.exit(-1);
        }
    }


}
```

```
import java.io.*;
public class TestFileOutputStream{
    public static void main(String args[]){
        int b = 0;
        FileInputStream in = null;
        FileOutputStream out = null;
        try{
            in = new FileInputStream("F:\\java_learning\\20191121\\IO\\TestFileInputStream.java");
            out = new FileOutputStream("F:\\java_learning\\20191121\\IO\\HW.java");
            while((b = in.read()) != -1){
                out.write(b);
            }
            in.close();
            out.close();
        }catch(FileNotFoundException e2){
            System.out.println("file is not found");
            System.exit(-1);
        }catch(IOException e1){
            System.out.println("copy error");
            System.exit(-1);
        }
        System.out.println("file is copied");
    }
}
```

```
import java.io.*;
public class TestFileReader{
    public static void main(String[] args){
        int c = 0;
        FileReader fr = null;
        try{
            fr = new FileReader("F:\\java_learning\\20191121\\IO\\TestFileReader.java");
            int ln = 0;
            while((c = fr.read()) != -1){ 
                // char ch = (char) fr.read();
                System.out.print((char) c);
                /*
                if (++ln>=100){
                    System.out.println();
                    ln = 0;
                }
                */
            }
            fr.close();
        } catch (FileNotFoundException e){
            System.out.println("file is not found"); 
        } catch(IOException e1){
            System.out.println("read file error");
        }
    }


}
```

```
import java.io.*;
public class TestFileWriter{
    public static void main(String args[]){
        FileWriter fw = null;
        try{
            fw = new FileWriter("F:\\java_learning\\20191121\\IO\\unicode.dat");
            for(int c=0; c<=50000; c++){
                fw.write(c);
            }

            fw.close();
        }catch(IOException e1){
            e1.printStackTrace();
            System.out.println("write error");
            System.exit(-1);
        }

    }
}
```
# **处理流**
![image.png](https://img.hacpai.com/file/2019/11/image-0fc3efbe.png)

# **1. 缓冲流**
![image.png](https://img.hacpai.com/file/2019/11/image-188a3b4e.png)

```
import java.io.*;
public class TestBufferStream{
    public static void main(String args[]){
        try{
            FileInputStream fis = new FileInputStream("F:\\java_learning\\20191121\\IO\\TestFileReader.java");
            BufferedInputStream bis = new BufferedInputStream(fis);
            int c = 0;
            System.out.println(bis.read());
            System.out.println(bis.read());
            bis.mark(100); //read from 100th character
            for(int i=0; i<=10 && (c=bis.read())!=-1; i++){
                System.out.println((char)c+" ");
            }
            System.out.println();
            bis.reset();
            
            for(int i=0; i<=10 && (c=bis.read())!=-1; i++){
                System.out.println((char)c+" ");
            }
            bis.close();

        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
```
```
import java.io.*;
public class TestBufferStream2{
    public static void main(String args[]){
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter("F:\\java_learning\\20191121\\IO\\dat2.txt"));
            BufferedReader br = new BufferedReader(new FileReader("F:\\java_learning\\20191121\\IO\\dat2.txt"));
            String s = null;
            for(int i=1; i<=100; i++){
                s = String.valueOf(Math.random());
                bw.write(s);
                bw.newLine();
            }
            bw.flush(); //将buffer里的内容倒光
            while((s=br.readLine()) != null){
                System.out.println(s);
            }
            bw.close();
            br.close();

        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
```
# **2.转换流**
![image.png](https://img.hacpai.com/file/2019/11/image-40271a70.png)
![image.png](https://img.hacpai.com/file/2019/11/image-b711291d.png)
ISO8859_1 : latin-1(western language)

```
import java.io.*;
public class TestTransform2{
    public static void main(String args[]){
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr); //readLine()
        String s = null;
        try{
            s = br.readLine();
            while(s != null){
                if(s.equalsIgnoreCase("exit")) break;
                System.out.println(s.toUpperCase());
                s = br.readLine();
            }
            br.close();
        } catch(IOException e){
            e.printStackTrace();
        }
    }
}
```
# **3. Print Stream**
![image.png](https://img.hacpai.com/file/2019/11/image-bc14c866.png)
```
import java.io.*;

public class TestPrintStream1{
    public static void main(String args[]){
        PrintStream ps = null;
        try{
            FileOutputStream fos = new FileOutputStream("F:\\java_learning\\20191122\\IO\\log.dat");
            ps = new PrintStream(fos);
        } catch(IOException e){
            e.printStackTrace();
        }
        if(ps != null){
            System.setOut(ps);  // set out value to be ps
        }
        int ln = 0;
        for(char c = 0; c<=60000; c++){
            System.out.print(c + " ");
            if(ln++ >= 100){
                System.out.println();
                ln = 0;  // print the amoount of 100 value,  then change to another line
            }
        }
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-438299ce.png)
```
//print the following code to console
import java.io.*;

public class TestPrintStream2{
    public static void main(String args[]){
        String filename = args[0];
        if(filename != null){
            list(filename, System.out); //System.out belongs to  PrintStream class
        }
    }

    public static void list(String f, PrintStream fs){
        try{
            BufferedReader br = new BufferedReader(new FileReader(f));
            String s =null;
            while((s=br.readLine()) != null){
                fs.println(s);
            }
            br.close();
        } catch(IOException e){
            fs.println("cannot read file");
        }
    }
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-4792e8f3.png)

![image.png](https://img.hacpai.com/file/2019/11/image-dcd679a7.png)

# **4.Object Stream**
![image.png](https://img.hacpai.com/file/2019/11/image-067fde8e.png)
```
import java.util.*;
import java.io.*;


public class TestObjectStream{
    public static void main(String args[]) throws Exception{
        T t = new T();
        t.k = 8;
        FileOutputStream fos = new FileOutputStream("F:\\java_learning\\20191122\\IO\\testObjectIO.dat");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(t);
        oos.flush();
        oos.close();

        FileInputStream fis = new FileInputStream("F:\\java_learning\\20191122\\IO\\testObjectIO.dat");
        ObjectInputStream ois = new ObjectInputStream(fis);
        T tReaded = (T) ois.readObject();
        System.out.println(tReaded.i + " " + tReaded.j + " " + tReaded.d + " " + tReaded.k);
    }
}

class T implements Serializable{
    int i = 10;
    int j = 9;
    double d = 2.3;
    transient int k = 15; // k is transparent => output k will be 0(default value)
}

```
![image.png](https://img.hacpai.com/file/2019/11/image-49036bfc.png)
自己控制序列化过程（prefer to let JDK control serializable process)

# **Summary**
![image.png](https://img.hacpai.com/file/2019/11/image-2b01e3a5.png)
- transient
- serializable
![image.png](https://img.hacpai.com/file/2019/11/image-04593835.png)




